# 🧠 AI Subscription Manager

A smart chatbot that helps you manage and track your subscriptions using the Gemini API.

## Features

- Natural language interaction for managing subscriptions
- Track subscription costs and renewal dates
- Get reminders for upcoming renewals
- Compare different subscription services
- Get cost-saving recommendations
- Beautiful, responsive UI with Tailwind CSS

## Setup

1. Clone this repository
2. Get a Gemini API key from the [Google AI Studio](https://makersuite.google.com/app/apikey)
3. Replace `YOUR_API_KEY` in `script.js` with your actual Gemini API key
4. Open `index.html` in your browser

## Example Questions

You can ask the AI assistant questions like:
- "I subscribed to Spotify for $9.99 per month. Remind me before it renews on May 28, 2025."
- "What subscriptions are due this week?"
- "How much am I spending on subscriptions this month?"
- "Suggest cheaper alternatives to Netflix."
- "Compare Spotify and YouTube Music."
- "Which subscriptions can I cancel to save money?"

## Technologies Used

- HTML5
- Tailwind CSS
- JavaScript (ES6+)
- Google's Gemini API

## Security Note

Make sure to keep your API key secure and never commit it to version control. In a production environment, you should:
1. Use environment variables
2. Implement proper API key management
3. Add rate limiting
4. Set up proper CORS policies

## License

MIT License - Feel free to use this code for your own projects! 