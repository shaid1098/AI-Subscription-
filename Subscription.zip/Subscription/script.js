// Replace with your actual Gemini API key
const GEMINI_API_KEY = 'AIzaSyC7kUVWlLqmvP2E5Os9QP0oecEy6XS22JM';
const GEMINI_API_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${GEMINI_API_KEY}`;

// DOM Elements
const userInput = document.getElementById('userInput');
const sendButton = document.getElementById('sendButton');
const loadingSpinner = document.getElementById('loadingSpinner');
const responseArea = document.getElementById('responseArea');
const charCount = document.getElementById('charCount');
const clearChatButton = document.getElementById('clearChat');
const themeToggle = document.getElementById('themeToggle');
const darkIcon = document.getElementById('darkIcon');
const lightIcon = document.getElementById('lightIcon');

// Subscription form elements
const subscriptionForm = document.getElementById('subscriptionForm');
const serviceName = document.getElementById('serviceName');
const planType = document.getElementById('planType');
const cost = document.getElementById('cost');
const billingCycle = document.getElementById('billingCycle');
const startDate = document.getElementById('startDate');
const renewalDate = document.getElementById('renewalDate');
const notes = document.getElementById('notes');
const subscriptionsContainer = document.getElementById('subscriptionsContainer');

// Additional DOM Elements
const addSubTab = document.getElementById('addSubTab');
const viewSubTab = document.getElementById('viewSubTab');
const totalMonthlyEl = document.getElementById('totalMonthly');
const activeSubsEl = document.getElementById('activeSubs');
const sortByNameBtn = document.getElementById('sortByName');
const sortByDateBtn = document.getElementById('sortByDate');
const exportDataBtn = document.getElementById('exportData');
const importDataBtn = document.getElementById('importData');

// Keep track of conversation context and subscriptions
let conversationHistory = [];
let subscriptions = JSON.parse(localStorage.getItem('subscriptions')) || [];

// Event Listeners
sendButton.addEventListener('click', handleSendMessage);
userInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        handleSendMessage();
    }
});

userInput.addEventListener('input', () => {
    const length = userInput.value.length;
    charCount.textContent = `${length}/500`;
    charCount.className = length > 500 ? 'text-red-500' : 'text-gray-500';
    sendButton.disabled = length > 500;
});

clearChatButton.addEventListener('click', () => {
    if (confirm('Are you sure you want to clear the chat?')) {
        responseArea.innerHTML = getWelcomeMessage();
        conversationHistory = [];
    }
});

themeToggle.addEventListener('click', toggleTheme);

// Event Listeners for new features
addSubTab.addEventListener('click', () => switchTab('add'));
viewSubTab.addEventListener('click', () => switchTab('view'));
sortByNameBtn.addEventListener('click', () => sortSubscriptions('name'));
sortByDateBtn.addEventListener('click', () => sortSubscriptions('date'));
exportDataBtn.addEventListener('click', exportSubscriptions);
importDataBtn.addEventListener('click', () => document.createElement('input').click());

// Subscription form handler
subscriptionForm.addEventListener('submit', (e) => {
    e.preventDefault();
    
    const subscription = {
        id: Date.now(),
        service: serviceName.value,
        plan: planType.value,
        cost: parseFloat(cost.value),
        billingCycle: billingCycle.value,
        startDate: startDate.value,
        renewalDate: renewalDate.value,
        notes: notes.value,
        status: 'active'
    };

    // Add subscription with animation
    subscriptions.push(subscription);
    saveSubscriptions();
    updateSubscriptionsList();
    updateStats();
    subscriptionForm.reset();

    // Set default dates
    const today = new Date().toISOString().split('T')[0];
    startDate.value = today;
    renewalDate.value = today;

    // Show success message
    appendMessage('system', `Added new subscription: ${subscription.service} (${subscription.plan}) at $${subscription.cost}/${subscription.billingCycle}`);
});

// Tab switching
function switchTab(tab) {
    const form = document.getElementById('subscriptionForm');
    const list = document.getElementById('subscriptionsList');
    
    if (tab === 'add') {
        form.classList.remove('hidden');
        list.classList.add('hidden');
        addSubTab.classList.add('bg-gray-800');
        viewSubTab.classList.remove('bg-gray-800');
    } else {
        form.classList.add('hidden');
        list.classList.remove('hidden');
        addSubTab.classList.remove('bg-gray-800');
        viewSubTab.classList.add('bg-gray-800');
    }
}

// Sort subscriptions
function sortSubscriptions(by) {
    subscriptions.sort((a, b) => {
        if (by === 'name') {
            return a.service.localeCompare(b.service);
        } else {
            return new Date(a.renewalDate) - new Date(b.renewalDate);
        }
    });
    updateSubscriptionsList();
}

// Export subscriptions
function exportSubscriptions() {
    const data = JSON.stringify(subscriptions, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'subscriptions.json';
    a.click();
    URL.revokeObjectURL(url);
}

// Import subscriptions
function importSubscriptions(event) {
    const file = event.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const importedData = JSON.parse(e.target.result);
                subscriptions = importedData;
                saveSubscriptions();
                updateSubscriptionsList();
                updateStats();
                appendMessage('system', 'Subscriptions imported successfully!');
            } catch (error) {
                appendMessage('error', 'Failed to import subscriptions. Invalid file format.');
            }
        };
        reader.readAsText(file);
    }
}

// Update statistics
function updateStats() {
    const totalMonthly = subscriptions.reduce((total, sub) => {
        const cost = parseFloat(sub.cost);
        if (sub.billingCycle === 'yearly') return total + (cost / 12);
        if (sub.billingCycle === 'quarterly') return total + (cost / 3);
        if (sub.billingCycle === 'weekly') return total + (cost * 4);
        return total + cost;
    }, 0);

    totalMonthlyEl.textContent = `$${totalMonthly.toFixed(2)}`;
    activeSubsEl.textContent = subscriptions.length;
}

// Initialize
function initialize() {
    // Set theme
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    document.documentElement.classList.toggle('dark', prefersDark);
    updateThemeIcon(prefersDark ? 'dark' : 'light');
    
    // Show welcome message
    responseArea.innerHTML = getWelcomeMessage();

    // Set default dates
    const today = new Date().toISOString().split('T')[0];
    startDate.value = today;
    renewalDate.value = today;

    // Load and display existing subscriptions
    updateSubscriptionsList();
    switchTab('add');
}

function toggleTheme() {
    const isDark = document.documentElement.classList.toggle('dark');
    updateThemeIcon(isDark ? 'dark' : 'light');
}

function updateThemeIcon(theme) {
    darkIcon.classList.toggle('hidden', theme !== 'light');
    lightIcon.classList.toggle('hidden', theme !== 'dark');
}

function getWelcomeMessage() {
    return `
        <div class="flex items-center gap-3 text-gray-300">
            <div class="animate-pulse flex gap-1">
                <div class="w-2 h-2 bg-blue-500 rounded-full"></div>
                <div class="w-2 h-2 bg-purple-500 rounded-full"></div>
                <div class="w-2 h-2 bg-pink-500 rounded-full"></div>
            </div>
            <span>AI Assistant is ready to help you manage subscriptions...</span>
        </div>
    `;
}

function saveSubscriptions() {
    localStorage.setItem('subscriptions', JSON.stringify(subscriptions));
}

function updateSubscriptionsList() {
    subscriptionsContainer.innerHTML = '';
    
    if (subscriptions.length === 0) {
        subscriptionsContainer.innerHTML = `
            <div class="text-center py-8">
                <svg class="w-16 h-16 mx-auto text-gray-600 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"></path>
                </svg>
                <p class="text-gray-500 text-sm">No subscriptions added yet.</p>
                <button onclick="switchTab('add')" class="mt-4 text-blue-500 text-sm hover:text-blue-400">Add your first subscription</button>
            </div>
        `;
        return;
    }

    subscriptions.forEach(sub => {
        const renewalDate = new Date(sub.renewalDate);
        const daysUntilRenewal = Math.ceil((renewalDate - new Date()) / (1000 * 60 * 60 * 24));
        const monthlyAmount = calculateMonthlyAmount(sub.cost, sub.billingCycle);
        
        const subscriptionEl = document.createElement('div');
        subscriptionEl.className = 'bg-gray-900 rounded-lg p-3 relative group hover:bg-gray-850 transition-colors';
        subscriptionEl.innerHTML = `
            <div class="flex justify-between items-start gap-2">
                <div class="flex-1">
                    <div class="flex items-center gap-2">
                        <h4 class="font-semibold text-sm">${sub.service}</h4>
                        <span class="text-xs px-1.5 py-0.5 rounded-full ${getBillingCycleColor(sub.billingCycle)}">${sub.billingCycle}</span>
                    </div>
                    <p class="text-xs text-gray-400">${sub.plan} - $${sub.cost}/${sub.billingCycle}</p>
                    <p class="text-xs text-gray-500">(≈$${monthlyAmount}/mo)</p>
                    ${sub.notes ? `<p class="text-xs text-gray-500 mt-1 italic">${sub.notes}</p>` : ''}
                </div>
                <div class="text-right flex flex-col items-end">
                    <span class="text-xs px-2 py-1 rounded-full ${getDaysColor(daysUntilRenewal)}">
                        ${formatDaysUntilRenewal(daysUntilRenewal)}
                    </span>
                    <div class="flex gap-1 mt-2">
                        <button 
                            onclick="editSubscription(${sub.id})" 
                            class="p-1 text-gray-500 hover:text-blue-500 opacity-0 group-hover:opacity-100 transition-opacity"
                            title="Edit Subscription"
                        >
                            <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path>
                            </svg>
                        </button>
                        <button 
                            onclick="cancelSubscription(${sub.id})" 
                            class="p-1 text-gray-500 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
                            title="Cancel Subscription"
                        >
                            <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                            </svg>
                        </button>
                    </div>
                </div>
            </div>
        `;
        subscriptionsContainer.appendChild(subscriptionEl);
    });

    updateStats();
}

function cancelSubscription(id) {
    if (confirm('Are you sure you want to cancel this subscription?')) {
        subscriptions = subscriptions.filter(sub => sub.id !== id);
        saveSubscriptions();
        updateSubscriptionsList();
        appendMessage('system', 'Subscription cancelled successfully.');
    }
}

async function handleSendMessage() {
    const message = userInput.value.trim();
    if (!message || message.length > 500) return;

    appendMessage('user', message);
    conversationHistory.push({ role: 'user', content: message });
    
    setLoading(true);
    
    try {
        const response = await sendToGemini(message);
        appendMessage('ai', response);
        conversationHistory.push({ role: 'assistant', content: response });
    } catch (error) {
        appendMessage('error', error.message);
    } finally {
        setLoading(false);
        userInput.value = '';
        charCount.textContent = '0/500';
    }
}

async function sendToGemini(message) {
    const systemContext = `You are an AI subscription management assistant. Your role is to help users manage their subscriptions effectively. 
Keep responses concise and focused on subscription-related queries. If users mention specific services like Netflix, Amazon, etc., 
acknowledge them and provide relevant information. Always maintain context of the conversation.

Current Subscriptions:
${formatSubscriptionsForAI()}`;

    const prompt = {
        contents: [{
            parts: [
                { text: systemContext },
                ...conversationHistory.map(msg => ({ text: `${msg.role}: ${msg.content}` })),
                { text: `user: ${message}` }
            ]
        }]
    };

    try {
        const response = await fetch(GEMINI_API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(prompt)
        });

        if (!response.ok) {
            const errorData = await response.json().catch(() => null);
            throw new Error(errorData?.error?.message || `API request failed: ${response.statusText}`);
        }

        const data = await response.json();
        if (!data.candidates?.[0]?.content?.parts?.[0]?.text) {
            throw new Error('Invalid response format from API');
        }
        return data.candidates[0].content.parts[0].text;
    } catch (error) {
        console.error('Gemini API Error:', error);
        throw error;
    }
}

function formatSubscriptionsForAI() {
    if (subscriptions.length === 0) {
        return "No active subscriptions.";
    }

    return subscriptions.map(sub => {
        const renewalDate = new Date(sub.renewalDate);
        const daysUntilRenewal = Math.ceil((renewalDate - new Date()) / (1000 * 60 * 60 * 24));
        const monthlyAmount = calculateMonthlyAmount(sub.cost, sub.billingCycle);
        
        return `- ${sub.service} (${sub.plan})
  Cost: $${sub.cost}/${sub.billingCycle} (≈$${monthlyAmount}/mo)
  Started: ${sub.startDate}
  Next Renewal: ${sub.renewalDate} (${daysUntilRenewal} days)
  ${sub.notes ? `Notes: ${sub.notes}` : ''}`
    }).join('\n\n');
}

function appendMessage(type, content) {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'chat-message animate-slide-up mb-4';
    
    const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    
    messageDiv.innerHTML = `
        <div class="font-medium text-gray-300 mb-2 flex justify-between">
            <span>${type === 'user' ? 'You' : type === 'system' ? 'System' : 'AI Assistant'}</span>
            <span class="text-sm text-gray-500">${timestamp}</span>
        </div>
        <div class="prose prose-invert">${formatMessage(content)}</div>
    `;
    
    responseArea.appendChild(messageDiv);
    responseArea.scrollTop = responseArea.scrollHeight;
}

function formatMessage(text) {
    return text
        .replace(/\n/g, '<br>')
        .replace(/\* (.*?)(<br|$)/g, '• $1$2')
        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
        .replace(/`(.*?)`/g, '<code>$1</code>');
}

function setLoading(isLoading) {
    sendButton.disabled = isLoading;
    loadingSpinner.classList.toggle('hidden', !isLoading);
    userInput.disabled = isLoading;
}

// Helper functions
function calculateMonthlyAmount(cost, cycle) {
    const amount = parseFloat(cost);
    switch (cycle) {
        case 'yearly': return (amount / 12).toFixed(2);
        case 'quarterly': return (amount / 3).toFixed(2);
        case 'weekly': return (amount * 4).toFixed(2);
        default: return amount.toFixed(2);
    }
}

function getBillingCycleColor(cycle) {
    const colors = {
        yearly: 'bg-purple-500/20 text-purple-400',
        monthly: 'bg-blue-500/20 text-blue-400',
        quarterly: 'bg-pink-500/20 text-pink-400',
        weekly: 'bg-green-500/20 text-green-400'
    };
    return colors[cycle] || 'bg-gray-500/20 text-gray-400';
}

function getDaysColor(days) {
    if (days <= 0) return 'bg-red-500/20 text-red-400';
    if (days <= 7) return 'bg-yellow-500/20 text-yellow-400';
    return 'bg-green-500/20 text-green-400';
}

function formatDaysUntilRenewal(days) {
    if (days <= 0) return 'Overdue';
    if (days === 1) return 'Tomorrow';
    if (days <= 7) return `${days}d left`;
    return `${days}d`;
}

// Initialize the app
initialize(); 